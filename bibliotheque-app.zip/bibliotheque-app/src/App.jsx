import { useState, useRef } from "react";

const SHELVES = [
  { id: "reading", label: "En cours", emoji: "◈", color: "#c4d9f9", accent: "#4a7fe0" },
  { id: "read",    label: "Lu",       emoji: "✿", color: "#c4f9e2", accent: "#1faa6e" },
  { id: "owned",   label: "Possédé",  emoji: "◇", color: "#f0c4f9", accent: "#a03ec9" },
  { id: "wishlist",label: "Wishlist", emoji: "♡", color: "#fde8c4", accent: "#e07c20" },
  { id: "creation",label: "Mes Créations", emoji: "✦", color: "#ffd6e0", accent: "#d94f7a" },
];

const PLATFORMS = ["Wattpad", "Book Nova", "AO3", "Scribble Hub", "Autre"];

const INIT = [
  { id:1, title:"A Court of Thorns and Roses", author:"Sarah J. Maas", shelf:"read", rating:5, note:"Absolument 🔥", price:9.99, cover:"", platform:"" },
  { id:2, title:"The Name of the Wind", author:"Patrick Rothfuss", shelf:"reading", rating:0, note:"", price:12.50, cover:"", platform:"" },
  { id:3, title:"Wynæl — Tome I", author:"Wynluna", shelf:"creation", rating:0, note:"Mon univers ᛞ̇", price:0, cover:"", platform:"Wattpad" },
];

function Stars({ v, onChange }) {
  const [h, setH] = useState(0);
  return (
    <span style={{cursor:"pointer",fontSize:"1.05rem",letterSpacing:1}}>
      {[1,2,3,4,5].map(s=>(
        <span key={s}
          onMouseEnter={()=>setH(s)} onMouseLeave={()=>setH(0)}
          onClick={()=>onChange(s===v?0:s)}
          style={{color: s<=(h||v)?"#f5a623":"#ddd", transition:"color .15s"}}
        >★</span>
      ))}
    </span>
  );
}

function CoverImg({ cover, accent, onChangeCover }) {
  const ref = useRef();
  const handleFile = e => {
    const f = e.target.files[0];
    if (!f) return;
    const r = new FileReader();
    r.onload = ev => onChangeCover(ev.target.result);
    r.readAsDataURL(f);
  };
  return (
    <div
      onClick={()=>ref.current.click()}
      style={{
        width:64, height:90, borderRadius:8, flexShrink:0, cursor:"pointer",
        background: cover ? "transparent" : accent+"22",
        border:`2px dashed ${accent}66`,
        overflow:"hidden", display:"flex", alignItems:"center", justifyContent:"center",
        position:"relative",
      }}
      title="Changer la couverture"
    >
      {cover
        ? <img src={cover} alt="cover" style={{width:"100%",height:"100%",objectFit:"cover"}}/>
        : <span style={{fontSize:"1.4rem",color:accent+"99"}}>📖</span>
      }
      <input ref={ref} type="file" accept="image/*" style={{display:"none"}} onChange={handleFile}/>
    </div>
  );
}

function BookCard({ book, onUpdate, onDelete }) {
  const shelf = SHELVES.find(s=>s.id===book.shelf);
  const [editNote, setEditNote] = useState(false);
  const [note, setNote] = useState(book.note);
  const [editUrl, setEditUrl] = useState(false);
  const [url, setUrl] = useState(book.cover||"");
  const isCreation = book.shelf === "creation";

  return (
    <div style={{
      display:"flex", gap:12, background:"rgba(255,255,255,0.9)",
      borderRadius:16, padding:"12px 12px 10px", marginBottom:10,
      boxShadow:`0 2px 14px ${shelf.accent}22`,
      border:`1.5px solid ${shelf.color}`,
      position:"relative",
    }}>
      <CoverImg
        cover={book.cover} accent={shelf.accent}
        onChangeCover={c=>onUpdate({...book,cover:c})}
      />
      <div style={{flex:1,minWidth:0}}>
        {/* Title */}
        <div style={{fontFamily:"'Cormorant Garamond',serif",fontWeight:700,fontSize:"0.98rem",color:"#1a1030",lineHeight:1.25,marginBottom:2}}>
          {book.title}
        </div>
        <div style={{fontSize:"0.75rem",color:"#999",marginBottom:5,fontFamily:"'DM Sans',sans-serif"}}>
          {book.author}{isCreation && book.platform ? <span style={{marginLeft:6,background:shelf.color,color:shelf.accent,borderRadius:10,padding:"1px 7px",fontSize:"0.68rem",fontWeight:600}}>{book.platform}</span> : null}
        </div>

        {/* Stars */}
        {!isCreation && <div style={{marginBottom:5}}><Stars v={book.rating} onChange={r=>onUpdate({...book,rating:r})}/></div>}

        {/* Price */}
        {!isCreation && (
          <div style={{display:"flex",alignItems:"center",gap:6,marginBottom:5}}>
            <span style={{fontSize:"0.72rem",color:"#bbb",fontFamily:"'DM Sans',sans-serif"}}>Prix :</span>
            <input
              type="number" min="0" step="0.01"
              value={book.price||""}
              onChange={e=>onUpdate({...book,price:parseFloat(e.target.value)||0})}
              placeholder="0.00"
              style={{
                width:60, fontSize:"0.78rem", border:"1px solid #e5ddf7",
                borderRadius:8, padding:"2px 6px", fontFamily:"'DM Sans',sans-serif",
                background:"#faf8ff", color:"#555",
              }}
            />
            <span style={{fontSize:"0.72rem",color:"#bbb"}}>€</span>
          </div>
        )}

        {/* Platform link for creations */}
        {isCreation && (
          <div style={{marginBottom:5,display:"flex",gap:6,alignItems:"center",flexWrap:"wrap"}}>
            <select
              value={book.platform||""}
              onChange={e=>onUpdate({...book,platform:e.target.value})}
              style={{fontSize:"0.72rem",border:"1px solid #ffd6e0",borderRadius:8,padding:"2px 6px",background:"#fff5f8",color:shelf.accent,fontFamily:"'DM Sans',sans-serif"}}
            >
              <option value="">Plateforme...</option>
              {PLATFORMS.map(p=><option key={p}>{p}</option>)}
            </select>
            {editUrl ? (
              <>
                <input value={url} onChange={e=>setUrl(e.target.value)} placeholder="https://..." autoFocus
                  style={{fontSize:"0.72rem",border:"1px solid #ffd6e0",borderRadius:8,padding:"2px 8px",flex:1,minWidth:80,fontFamily:"'DM Sans',sans-serif"}}
                  onKeyDown={e=>{if(e.key==="Enter"){onUpdate({...book,link:url});setEditUrl(false);}}}
                />
                <button onClick={()=>{onUpdate({...book,link:url});setEditUrl(false);}} style={{background:shelf.accent,color:"#fff",border:"none",borderRadius:8,padding:"2px 8px",fontSize:"0.7rem",cursor:"pointer"}}>OK</button>
              </>
            ) : (
              book.link
                ? <a href={book.link} target="_blank" rel="noreferrer" style={{fontSize:"0.72rem",color:shelf.accent,textDecoration:"underline"}}>Voir ↗</a>
                : <span onClick={()=>setEditUrl(true)} style={{fontSize:"0.72rem",color:"#ccc",cursor:"pointer"}}>+ lien</span>
            )}
          </div>
        )}

        {/* Shelf selector */}
        <select
          value={book.shelf}
          onChange={e=>onUpdate({...book,shelf:e.target.value})}
          style={{
            fontSize:"0.7rem", border:`1px solid ${shelf.accent}66`,
            borderRadius:8, padding:"2px 7px",
            background:shelf.color+"bb", color:shelf.accent,
            fontFamily:"'DM Sans',sans-serif", cursor:"pointer", marginBottom:5,
          }}
        >
          {SHELVES.map(s=><option key={s.id} value={s.id}>{s.emoji} {s.label}</option>)}
        </select>

        {/* Note */}
        {editNote ? (
          <div style={{display:"flex",gap:5}}>
            <input value={note} onChange={e=>setNote(e.target.value)}
              onKeyDown={e=>{if(e.key==="Enter"){onUpdate({...book,note});setEditNote(false);}}}
              placeholder="Ton avis..." autoFocus
              style={{flex:1,fontSize:"0.74rem",border:"1px solid #e0d4f7",borderRadius:8,padding:"3px 8px",fontFamily:"'DM Sans',sans-serif"}}
            />
            <button onClick={()=>{onUpdate({...book,note});setEditNote(false);}}
              style={{background:shelf.accent,color:"#fff",border:"none",borderRadius:8,padding:"3px 8px",fontSize:"0.7rem",cursor:"pointer"}}>OK</button>
          </div>
        ) : (
          <div onClick={()=>setEditNote(true)}
            style={{fontSize:"0.74rem",color:book.note?"#555":"#ccc",fontStyle:book.note?"italic":"normal",cursor:"pointer",fontFamily:"'DM Sans',sans-serif"}}
          >{book.note||"＋ Note..."}</div>
        )}
      </div>

      {/* Delete */}
      <button onClick={()=>onDelete(book.id)}
        style={{position:"absolute",top:8,right:8,background:"none",border:"none",cursor:"pointer",color:"#ddd",fontSize:"0.8rem"}}
      >✕</button>
    </div>
  );
}

function Modal({ shelves, onAdd, onClose }) {
  const [d, setD] = useState({ title:"", author:"", shelf:"owned", price:"", platform:"", cover:"" });
  const ref = useRef();
  const isCreation = d.shelf === "creation";
  const set = k => e => setD({...d,[k]:e.target.value});
  const handleFile = e => {
    const f = e.target.files[0]; if(!f)return;
    const r = new FileReader();
    r.onload = ev => setD({...d,cover:ev.target.result});
    r.readAsDataURL(f);
  };
  const submit = () => {
    if(!d.title.trim()) return;
    onAdd({...d, price:parseFloat(d.price)||0, rating:0, note:""});
    onClose();
  };
  const inp = {
    width:"100%", padding:"9px 12px", borderRadius:10,
    border:"1.5px solid #ecddf7", fontSize:"0.86rem",
    fontFamily:"'DM Sans',sans-serif", background:"#fdf8ff",
    boxSizing:"border-box", outline:"none", marginBottom:10, color:"#333",
  };
  return (
    <div style={{position:"fixed",inset:0,background:"rgba(20,5,40,0.4)",display:"flex",alignItems:"center",justifyContent:"center",zIndex:200,backdropFilter:"blur(5px)"}}>
      <div style={{background:"#fff",borderRadius:22,padding:"26px 22px",width:330,boxShadow:"0 10px 50px #a03ec944",maxHeight:"90vh",overflowY:"auto"}}>
        <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:"1.3rem",fontWeight:700,color:"#1a1030",marginBottom:18}}>✦ Ajouter</div>

        {/* Cover upload */}
        <div style={{display:"flex",gap:12,marginBottom:12,alignItems:"center"}}>
          <div onClick={()=>ref.current.click()}
            style={{width:54,height:76,borderRadius:8,border:"2px dashed #d4b5f0",display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer",overflow:"hidden",flexShrink:0,background:"#f9f4ff"}}
          >
            {d.cover?<img src={d.cover} style={{width:"100%",height:"100%",objectFit:"cover"}}/>:<span style={{fontSize:"1.3rem"}}>📖</span>}
            <input ref={ref} type="file" accept="image/*" style={{display:"none"}} onChange={handleFile}/>
          </div>
          <div style={{flex:1,fontSize:"0.75rem",color:"#aaa",lineHeight:1.5,fontFamily:"'DM Sans',sans-serif"}}>
            Clique pour ajouter une couverture, ou colle une URL ↓
            <input value={d.coverUrl||""} onChange={e=>setD({...d,cover:e.target.value,coverUrl:e.target.value})}
              placeholder="https://..." style={{...inp,marginTop:6,marginBottom:0,fontSize:"0.72rem",padding:"5px 10px"}}/>
          </div>
        </div>

        <input style={inp} placeholder="Titre *" value={d.title} onChange={set("title")}/>
        <input style={inp} placeholder="Auteur(e)" value={d.author} onChange={set("author")}/>

        <select value={d.shelf} onChange={set("shelf")} style={{...inp,cursor:"pointer"}}>
          {shelves.map(s=><option key={s.id} value={s.id}>{s.emoji} {s.label}</option>)}
        </select>

        {!isCreation && (
          <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:10}}>
            <input type="number" min="0" step="0.01" style={{...inp,marginBottom:0,flex:1}} placeholder="Prix (€)" value={d.price} onChange={set("price")}/>
          </div>
        )}

        {isCreation && (
          <select value={d.platform} onChange={set("platform")} style={{...inp,cursor:"pointer"}}>
            <option value="">Plateforme de publication...</option>
            {PLATFORMS.map(p=><option key={p}>{p}</option>)}
          </select>
        )}

        <div style={{display:"flex",gap:10,marginTop:4}}>
          <button onClick={submit} style={{flex:1,background:"linear-gradient(135deg,#a03ec9,#d94f7a)",color:"#fff",border:"none",borderRadius:12,padding:10,fontSize:"0.88rem",fontWeight:600,cursor:"pointer",fontFamily:"'DM Sans',sans-serif"}}>Ajouter</button>
          <button onClick={onClose} style={{flex:1,background:"#f3f0f8",color:"#999",border:"none",borderRadius:12,padding:10,fontSize:"0.88rem",cursor:"pointer",fontFamily:"'DM Sans',sans-serif"}}>Annuler</button>
        </div>
      </div>
    </div>
  );
}

export default function App() {
  const [books, setBooks] = useState(INIT);
  const [nextId, setNextId] = useState(20);
  const [showAdd, setShowAdd] = useState(false);
  const [search, setSearch] = useState("");
  const [activeShelf, setActiveShelf] = useState("all");

  const update = u => setBooks(books.map(b=>b.id===u.id?u:b));
  const remove = id => setBooks(books.filter(b=>b.id!==id));
  const add = d => { setBooks([...books,{...d,id:nextId}]); setNextId(nextId+1); };

  const filtered = books.filter(b => {
    const ms = activeShelf==="all" || b.shelf===activeShelf;
    const q = search.toLowerCase();
    const mq = !q || b.title.toLowerCase().includes(q) || b.author.toLowerCase().includes(q);
    return ms && mq;
  });

  // Valeur collection = livres possédés + wishlist
  const totalValue = books.filter(b=>b.shelf==="owned"||b.shelf==="reading"||b.shelf==="read").reduce((s,b)=>s+(b.price||0),0);
  const wishValue  = books.filter(b=>b.shelf==="wishlist").reduce((s,b)=>s+(b.price||0),0);

  const counts = {};
  SHELVES.forEach(s=>{ counts[s.id]=books.filter(b=>b.shelf===s.id).length; });

  return (
    <div style={{minHeight:"100vh",background:"linear-gradient(160deg,#fdf0fa 0%,#eef3ff 45%,#f0fff8 100%)",fontFamily:"'DM Sans',sans-serif",paddingBottom:60}}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@600;700&family=DM+Sans:wght@300;400;500;600&display=swap');
        *{box-sizing:border-box;}
        input:focus,select:focus{outline:none;border-color:#a03ec9 !important;}
        ::-webkit-scrollbar{width:4px;}
        ::-webkit-scrollbar-thumb{background:#e0c8f0;border-radius:4px;}
      `}</style>

      {/* HEADER */}
      <div style={{background:"rgba(255,255,255,0.75)",backdropFilter:"blur(14px)",borderBottom:"1px solid #ecddf7",padding:"16px 16px 12px",position:"sticky",top:0,zIndex:10}}>
        <div style={{display:"flex",alignItems:"flex-start",justifyContent:"space-between",marginBottom:12}}>
          <div>
            <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:"1.55rem",fontWeight:700,color:"#1a1030",letterSpacing:"-0.5px",lineHeight:1}}>
              ᛞ̇ Ma Bibliothèque
            </div>
            <div style={{fontSize:"0.7rem",color:"#a03ec9",fontWeight:500,letterSpacing:.5,marginTop:3}}>
              {books.length} livres · <span style={{color:"#1faa6e"}}>Collection {totalValue.toFixed(2)} €</span>
              {wishValue>0&&<span style={{color:"#e07c20"}}> · Wishlist {wishValue.toFixed(2)} €</span>}
            </div>
          </div>
          <button onClick={()=>setShowAdd(true)} style={{background:"linear-gradient(135deg,#a03ec9,#d94f7a)",color:"#fff",border:"none",borderRadius:50,width:42,height:42,fontSize:"1.4rem",cursor:"pointer",boxShadow:"0 4px 16px #a03ec944",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>＋</button>
        </div>

        {/* Stats bar */}
        <div style={{display:"flex",gap:8,marginBottom:12,overflowX:"auto",paddingBottom:2}}>
          {SHELVES.map(s=>(
            <div key={s.id} style={{background:s.color+"cc",borderRadius:10,padding:"4px 10px",flexShrink:0,textAlign:"center"}}>
              <div style={{fontSize:"0.65rem",color:s.accent,fontWeight:600}}>{s.emoji} {s.label}</div>
              <div style={{fontSize:"1rem",fontWeight:700,color:s.accent,fontFamily:"'Cormorant Garamond',serif"}}>{counts[s.id]||0}</div>
            </div>
          ))}
        </div>

        <input value={search} onChange={e=>setSearch(e.target.value)}
          placeholder="🔍 Titre, auteur..."
          style={{width:"100%",padding:"8px 14px",borderRadius:12,border:"1.5px solid #e8d8f8",fontSize:"0.83rem",background:"rgba(255,255,255,0.9)",fontFamily:"'DM Sans',sans-serif",color:"#333"}}
        />
      </div>

      {/* TABS */}
      <div style={{display:"flex",gap:7,padding:"12px 14px 0",overflowX:"auto"}}>
        {[{id:"all",label:"Tout",emoji:"◉",color:"#1a1030",bg:"#1a1030"},...SHELVES].map(s=>{
          const active = activeShelf===s.id;
          return (
            <button key={s.id} onClick={()=>setActiveShelf(s.id)} style={{
              padding:"5px 13px",borderRadius:20,border:"none",cursor:"pointer",
              fontFamily:"'DM Sans',sans-serif",fontSize:"0.75rem",fontWeight:600,
              background: active?(s.accent||s.bg):(s.color+"99"||"#f0ebfa"),
              color: active?"#fff":(s.accent||"#888"),
              whiteSpace:"nowrap",transition:"all .2s",flexShrink:0,
            }}>
              {s.emoji} {s.label||"Tout"} {s.id!=="all"?`(${counts[s.id]||0})`:`(${books.length})`}
            </button>
          );
        })}
      </div>

      {/* BOOKS */}
      <div style={{padding:"14px 14px 0"}}>
        {activeShelf==="all"
          ? SHELVES.map(s=>{
              const sb = filtered.filter(b=>b.shelf===s.id);
              if(!sb.length && search) return null;
              const sv = sb.filter(b=>b.shelf!=="wishlist"&&b.shelf!=="creation").reduce((a,b)=>a+(b.price||0),0);
              return (
                <div key={s.id} style={{marginBottom:26}}>
                  <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:10}}>
                    <span style={{fontFamily:"'Cormorant Garamond',serif",fontWeight:700,fontSize:"1.05rem",color:s.accent}}>{s.emoji} {s.label}</span>
                    <span style={{background:s.color,color:s.accent,borderRadius:20,padding:"1px 8px",fontSize:"0.68rem",fontFamily:"'DM Sans',sans-serif",fontWeight:600}}>{sb.length}</span>
                    {sv>0&&<span style={{fontSize:"0.68rem",color:"#1faa6e",fontWeight:600}}>{sv.toFixed(2)} €</span>}
                  </div>
                  {sb.length===0
                    ? <div style={{fontSize:"0.78rem",color:"#ccc",fontStyle:"italic",paddingLeft:4}}>Rien ici pour l'instant...</div>
                    : sb.map(b=><BookCard key={b.id} book={b} onUpdate={update} onDelete={remove}/>)
                  }
                </div>
              );
            })
          : filtered.length===0
            ? <div style={{textAlign:"center",color:"#ccc",fontSize:"0.9rem",marginTop:50,fontStyle:"italic"}}>Aucun livre ici... ✦</div>
            : filtered.map(b=><BookCard key={b.id} book={b} onUpdate={update} onDelete={remove}/>)
        }
      </div>

      {showAdd && <Modal shelves={SHELVES} onAdd={add} onClose={()=>setShowAdd(false)}/>}
    </div>
  );
}
