# ᛞ̇ Ma Bibliothèque — Guide d'installation

## Mettre l'appli sur ton écran d'accueil (gratuit)

### Étape 1 — Créer un compte Vercel
1. Va sur **vercel.com**
2. Clique "Sign Up" → connecte-toi avec GitHub (crée un compte GitHub si t'en as pas, c'est rapide)

### Étape 2 — Mettre le projet sur GitHub
1. Va sur **github.com** → "New repository"
2. Nomme-le `ma-bibliotheque`, laisse tout par défaut → "Create repository"
3. Sur la page qui s'affiche, clique "uploading an existing file"
4. Glisse-dépose **tout le contenu** de ce dossier (les fichiers `package.json`, et les dossiers `src/` et `public/`)
5. Clique "Commit changes"

### Étape 3 — Déployer sur Vercel
1. Sur Vercel, clique "Add New Project"
2. Sélectionne ton repo `ma-bibliotheque`
3. Laisse tout par défaut → clique **Deploy**
4. Attends ~1 minute → Vercel te donne un lien comme `ma-bibliotheque.vercel.app` 🎉

### Étape 4 — Ajouter à l'écran d'accueil
**Sur iPhone (Safari) :**
1. Ouvre ton lien Vercel dans Safari
2. Clique l'icône Partager (carré avec flèche ↑)
3. → "Sur l'écran d'accueil"
4. → "Ajouter" ✓

**Sur Android (Chrome) :**
1. Ouvre ton lien dans Chrome
2. Menu ⋮ → "Ajouter à l'écran d'accueil"
3. → "Ajouter" ✓

L'appli s'ouvre alors en plein écran comme une vraie appli ! ✨

---
Note : les données sont sauvegardées dans le navigateur (localStorage), 
donc elles restent même si tu fermes l'appli.
